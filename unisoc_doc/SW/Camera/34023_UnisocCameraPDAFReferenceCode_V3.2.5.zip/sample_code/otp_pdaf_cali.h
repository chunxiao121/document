#ifndef _OTP_PDAF_CALI_H_
#define _OTP_PDAF_CALI_H_

#include <sstream>


#ifdef __cplusplus
extern "C"
{
#endif


#ifdef PDAF_CALIBRATION_DLL_EXPORTS
#define PDAF_CALIBRATION_API __declspec(dllexport)
#else
#define PDAF_CALIBRATION_API __declspec(dllimport)
#endif

// SPC API
typedef int(*FNUC_CAL_OTP_PDAF_SPC_INIT)(const char *spc_param_name);
PDAF_CALIBRATION_API int cal_otp_pdaf_spc_init(const char *spc_param_name);

typedef int (*FNUC_CAL_OTP_PDAF_SPC_GETRAW)(const char *raw_path[], int ***raw_image);
PDAF_CALIBRATION_API int cal_otp_pdaf_spc_getraw (const char *raw_path[], int ***raw_image);

typedef int (*FNUC_CAL_OTP_PDAF_SPC_GETRAW_V)(const char *raw_path[], int ***raw_image);
PDAF_CALIBRATION_API int cal_otp_pdaf_spc_getraw_v (const char *raw_path[], int ***raw_image);

typedef int (*FNUC_CAL_OTP_PDAF_SPC)(int **raw_image, unsigned char *otp_spc_out, unsigned char *otp_ppp_out);
PDAF_CALIBRATION_API int cal_otp_pdaf_spc(int **raw_image, unsigned char *otp_spc_out, unsigned char *otp_ppp_out);

typedef int (*FNUC_CAL_OTP_PDAF_SPC_VERIFY)(int **raw_image, unsigned char *spc_map_reference, unsigned char *otp_ppp_out);
PDAF_CALIBRATION_API int cal_otp_pdaf_spc_verify (int **raw_image, unsigned char *spc_map_reference, unsigned char *otp_ppp_out);

typedef int (*FNUC_CAL_OTP_PDAF_SPC_RELEASERAW)(int **raw_image);
PDAF_CALIBRATION_API int cal_otp_pdaf_spc_releaseraw (int **raw_image);

typedef int (*FNUC_CAL_OTP_PDAF_SPC_RELEASERAW_V)(int **raw_image);
PDAF_CALIBRATION_API int cal_otp_pdaf_spc_releaseraw_v (int **raw_image);

typedef int (*FNUC_CAL_OTP_PDAF_SPC_DEINIT)();
PDAF_CALIBRATION_API int cal_otp_pdaf_spc_deinit ();

// DCC API
typedef int(*FNUC_CAL_OTP_PDAF_DCC_INIT)(const char *dcc_param_name);
PDAF_CALIBRATION_API int cal_otp_pdaf_dcc_init(const char *dcc_param_name);

typedef int(*FNUC_CAL_OTP_PDAF_DCC_GETRAW)(const char *raw_path[], int ***raw_image, int dcc_raw_number);
PDAF_CALIBRATION_API int cal_otp_pdaf_dcc_getraw(const char *raw_path[], int ***raw_image, int dcc_raw_number);

typedef int (*FNUC_CAL_OTP_PDAF_DCC_GETRAW_V) (const char *raw_path[], int ***raw_image);
PDAF_CALIBRATION_API int cal_otp_pdaf_dcc_getraw_v (const char *raw_path[], int ***raw_image);

typedef int (*FNUC_CAL_OTP_PDAF_DCC)(int **raw_image, unsigned char *otp_spc_in, int VCM_LOW_BND, int VCM_UPP_BND, unsigned char *dcc_result_out, unsigned char *otp_ppp_out);
PDAF_CALIBRATION_API int cal_otp_pdaf_dcc(int **raw_image, unsigned char *otp_spc_in, int VCM_LOW_BND, int VCM_UPP_BND, unsigned char *dcc_result_out, unsigned char *otp_ppp_out);

typedef int (*FNUC_CAL_OTP_PDAF_DCC_GET_INFOCUS_VCM)(int **raw_image, unsigned char *otp_spc_in, unsigned char *otp_dcc_in, int &vcm_offset);
PDAF_CALIBRATION_API int cal_otp_pdaf_dcc_get_infocus_vcm (int **raw_image, unsigned char *otp_spc_in, unsigned char *otp_dcc_in, int &vcm_offset);

typedef int (*FNUC_CAL_OTP_PDAF_DCC_RELEASERAW)(int **raw_image);
PDAF_CALIBRATION_API int cal_otp_pdaf_dcc_releaseraw (int **raw_image);

typedef int (*FNUC_CAL_OTP_PDAF_DCC_RELEASERAW_V)(int **raw_image);
PDAF_CALIBRATION_API int cal_otp_pdaf_dcc_releaseraw_v (int **raw_image);

typedef int (*FNUC_CAL_OTP_PDAF_DCC_DEINIT)();
PDAF_CALIBRATION_API int cal_otp_pdaf_dcc_deinit ();

// SPC correction API


#ifdef __cplusplus
}
#endif

#endif