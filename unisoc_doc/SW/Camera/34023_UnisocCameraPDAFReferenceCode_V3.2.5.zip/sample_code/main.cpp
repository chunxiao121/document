#include "otp_pdaf_cali.h"
#include <windows.h>
#include <string.h>


#define ERR_CODE_PASS						0
#define ERR_CODE_RAW_READ_FAIL				1
#define ERR_CODE_RAW_LUMA_CHECK_FAIL		2
#define ERR_CODE_RAW_PDPIX_CHECK_FAIL		3  
#define ERR_CODE_DCC_GET_PD_FAIL			4
#define ERR_CODE_DCC_VERIFICATION_FAIL		5
#define ERR_CODE_DCC_GET_SPC_GAIN_FAIL		6
#define ERR_CODE_PD_POSITION_ERR			7
#define ERR_CODE_SPC_VERIFICATION_FAIL		8
#define ERR_CODE_PARAM_READ_FAIL			9
#define ERR_CODE_DCC_NEGATIVE			    10
#define ERR_CODE_OUT_ERROR_SCOPE			11

#define SPC_RAW_SEQUENCE_NUMBER		2
#define DCC_RAW_SEQUENCE_NUMBER		6
#define SPC_RAW_SEQUENCE_NUMBER_V	1
#define DCC_RAW_SEQUENCE_NUMBER_V   1

#define SPC_MAP_W				9    // equal to SPC_MAP_W in spc_param_setting
#define SPC_MAP_H				7    // equal to SPC_MAP_H in spc_param_setting
#define DCC_XKNOT_NUM			8    // equal to DCC_XKNOT_NUM in dcc_param_setting
#define DCC_YKNOT_NUM			8    // equal to DCC_YKNOT_NUM in dcc_param_setting
#define PD_PROFILE_TABLE_NUM	16	

#define SPC_DCC_SWITCH		0	//0: first spc then dcc	1:only spc	2:only dcc

#define error_scope			30

int main(int argc, char* argv[])
{
    int rtn = 0;

	HINSTANCE hDll = NULL;

	FNUC_CAL_OTP_PDAF_SPC_INIT				cal_otp_pdaf_spc_init		     = NULL;
	FNUC_CAL_OTP_PDAF_SPC_GETRAW			cal_otp_pdaf_spc_getraw		     = NULL;
	FNUC_CAL_OTP_PDAF_SPC_GETRAW_V			cal_otp_pdaf_spc_getraw_v        = NULL;
    FNUC_CAL_OTP_PDAF_SPC					cal_otp_pdaf_spc			     = NULL;
	FNUC_CAL_OTP_PDAF_SPC_VERIFY			cal_otp_pdaf_spc_verify		     = NULL;
	FNUC_CAL_OTP_PDAF_SPC_RELEASERAW		cal_otp_pdaf_spc_releaseraw	     = NULL;
	FNUC_CAL_OTP_PDAF_SPC_RELEASERAW_V		cal_otp_pdaf_spc_releaseraw_v    = NULL;
	FNUC_CAL_OTP_PDAF_SPC_DEINIT			cal_otp_pdaf_spc_deinit		     = NULL;

	FNUC_CAL_OTP_PDAF_DCC_INIT				cal_otp_pdaf_dcc_init			 = NULL;
	FNUC_CAL_OTP_PDAF_DCC_GETRAW			cal_otp_pdaf_dcc_getraw			 = NULL;
	FNUC_CAL_OTP_PDAF_DCC_GETRAW_V			cal_otp_pdaf_dcc_getraw_v		 = NULL;
    FNUC_CAL_OTP_PDAF_DCC					cal_otp_pdaf_dcc				 = NULL;
    FNUC_CAL_OTP_PDAF_DCC_GET_INFOCUS_VCM	cal_otp_pdaf_dcc_get_infocus_vcm = NULL;
	FNUC_CAL_OTP_PDAF_DCC_RELEASERAW		cal_otp_pdaf_dcc_releaseraw		 = NULL;
	FNUC_CAL_OTP_PDAF_DCC_RELEASERAW_V		cal_otp_pdaf_dcc_releaseraw_v	 = NULL;
	FNUC_CAL_OTP_PDAF_DCC_DEINIT			cal_otp_pdaf_dcc_deinit			 = NULL;

	// pd pixel profile parameter
	unsigned char otp_ppp_out[PD_PROFILE_TABLE_NUM];
	unsigned char infocus_pos_error = 0;

	// spc parameter
	std::string spc_raw_path[SPC_RAW_SEQUENCE_NUMBER] = {"spc_raw_0.raw"/*"dnp_0.raw"*/,				
														 "spc_raw_1.raw"/*"dnp_1.raw"*/,			
														};							// input raw file path, use absolute path NOT use relative path
	std::string spc_parameter = "_spc_param_sensorname_normal.txt";						// input spc parameter path, use absolute path NOT use relative path
	unsigned char spc_gain_map[SPC_MAP_W*SPC_MAP_H*2*2];
	// spc verify parameter
	std::string spc_verify_raw_path[SPC_RAW_SEQUENCE_NUMBER_V] = { "spc_raw_2.raw"/*"dnp_2.raw"*/	};  // input raw file path, use absolute path NOT use relative path
	std::string spc_verify_parameter = "_spc_param_sensorname_normal.txt";				// input spc parameter path, use absolute path NOT use relative path
	unsigned char otp_spc_in[SPC_MAP_W*SPC_MAP_H*2*2];
	// dcc parameter
	std::string dcc_raw_path[DCC_RAW_SEQUENCE_NUMBER] = { "00.raw",
														  "01.raw", 
														  "02.raw",  
														  "03.raw",  
														  "04.raw",  
														  "05.raw",
														};							// input raw file path, use absolute path NOT use relative path	
	std::string dcc_parameter = "_dcc_param_sensorname_normal.txt";						// input dcc parameter path, use absolute path NOT use relative path
	unsigned char dcc_coef_map[DCC_XKNOT_NUM*DCC_YKNOT_NUM*2];
	int VCM_LOW_BND = 270/*400300*/;
	int VCM_UPP_BND = 515/*650550*/;
	// dcc verify parameter
	std::string dcc_verify_raw_path[DCC_RAW_SEQUENCE_NUMBER_V] = { "dcc_verify.raw" };		// input raw file path, use absolute path NOT use relative path  
	std::string dcc_verify_parameter = "_dcc_param_sensorname_normal.txt";				// input dcc parameter path, use absolute path NOT use relative path
	unsigned char otp_dcc_in[DCC_XKNOT_NUM*DCC_YKNOT_NUM*2];
	int current_vcm_pos = 466;
	
	/*get dll handle*/
    hDll = LoadLibrary(L"pdaf_calibration_dll.dll");
    if (hDll == NULL){
        printf("Failed to load pdaf_calibation.dll\n");
        goto EXIT;
    }
    
    /*get spc function pointer*/
	cal_otp_pdaf_spc_init = (FNUC_CAL_OTP_PDAF_SPC_INIT)GetProcAddress(hDll, "cal_otp_pdaf_spc_init");
    if (cal_otp_pdaf_spc_init == NULL){
        printf("Failed to GetProcAddress cal_otp_pdaf_spc_init\n");
        goto EXIT;
    }

	cal_otp_pdaf_spc_getraw = (FNUC_CAL_OTP_PDAF_SPC_GETRAW)GetProcAddress(hDll, "cal_otp_pdaf_spc_getraw");
    if (cal_otp_pdaf_spc_getraw == NULL){
        printf("Failed to GetProcAddress cal_otp_pdaf_spc_getraw\n");
        goto EXIT;
    }

	cal_otp_pdaf_spc_getraw_v = (FNUC_CAL_OTP_PDAF_SPC_GETRAW_V)GetProcAddress(hDll, "cal_otp_pdaf_spc_getraw_v");
    if (cal_otp_pdaf_spc_getraw_v == NULL){
        printf("Failed to GetProcAddress cal_otp_pdaf_spc_getraw_v\n");
        goto EXIT;
    }

	cal_otp_pdaf_spc_getraw = (FNUC_CAL_OTP_PDAF_SPC_GETRAW)GetProcAddress(hDll, "cal_otp_pdaf_spc_getraw");
    if (cal_otp_pdaf_spc_getraw == NULL){
        printf("Failed to GetProcAddress cal_otp_pdaf_spc_getraw\n");
        goto EXIT;
    }

	cal_otp_pdaf_spc = (FNUC_CAL_OTP_PDAF_SPC)GetProcAddress(hDll, "cal_otp_pdaf_spc");
    if (cal_otp_pdaf_spc == NULL){
        printf("Failed to GetProcAddress cal_otp_pdaf_spc\n");
        goto EXIT;
    }

    cal_otp_pdaf_spc_verify = (FNUC_CAL_OTP_PDAF_SPC_VERIFY)GetProcAddress(hDll, "cal_otp_pdaf_spc_verify");
    if (cal_otp_pdaf_spc_verify == NULL){
        printf("Failed to GetProcAddress cal_otp_pdaf_spc_verify\n");
        goto EXIT;
    }

	cal_otp_pdaf_spc_releaseraw = (FNUC_CAL_OTP_PDAF_SPC_RELEASERAW)GetProcAddress(hDll, "cal_otp_pdaf_spc_releaseraw");
    if (cal_otp_pdaf_spc_releaseraw == NULL){
        printf("Failed to GetProcAddress cal_otp_pdaf_spc_releaseraw\n");
        goto EXIT;
    }

	cal_otp_pdaf_spc_releaseraw_v = (FNUC_CAL_OTP_PDAF_SPC_RELEASERAW_V)GetProcAddress(hDll, "cal_otp_pdaf_spc_releaseraw_v");
    if (cal_otp_pdaf_spc_releaseraw_v == NULL){
        printf("Failed to GetProcAddress cal_otp_pdaf_spc_releaseraw_v\n");
        goto EXIT;
    }

	cal_otp_pdaf_spc_deinit = (FNUC_CAL_OTP_PDAF_SPC_DEINIT)GetProcAddress(hDll, "cal_otp_pdaf_spc_deinit");
    if (cal_otp_pdaf_spc_deinit == NULL){
        printf("Failed to GetProcAddress cal_otp_pdaf_spc_deinit\n");
        goto EXIT;
    }
  
	/*get dcc function pointer*/
	cal_otp_pdaf_dcc_init = (FNUC_CAL_OTP_PDAF_DCC_INIT)GetProcAddress(hDll, "cal_otp_pdaf_dcc_init");
    if (cal_otp_pdaf_dcc_init == NULL){
        printf("Failed to GetProcAddress cal_otp_pdaf_dcc_init\n");
        goto EXIT;
    }

	cal_otp_pdaf_dcc_getraw = (FNUC_CAL_OTP_PDAF_DCC_GETRAW)GetProcAddress(hDll, "cal_otp_pdaf_dcc_getraw");
    if (cal_otp_pdaf_dcc_getraw == NULL){
        printf("Failed to GetProcAddress cal_otp_pdaf_dcc_getraw\n");
        goto EXIT;
    }

	cal_otp_pdaf_dcc_getraw_v = (FNUC_CAL_OTP_PDAF_DCC_GETRAW_V)GetProcAddress(hDll, "cal_otp_pdaf_dcc_getraw_v");
    if (cal_otp_pdaf_dcc_getraw_v == NULL){
        printf("Failed to GetProcAddress cal_otp_pdaf_dcc_getraw_v\n");
        goto EXIT;
    }

	cal_otp_pdaf_dcc = (FNUC_CAL_OTP_PDAF_DCC)GetProcAddress(hDll, "cal_otp_pdaf_dcc");
    if (cal_otp_pdaf_dcc == NULL){
        printf("Failed to GetProcAddress cal_otp_pdaf_dcc\n");
        goto EXIT;
    }

	cal_otp_pdaf_dcc_get_infocus_vcm = (FNUC_CAL_OTP_PDAF_DCC_GET_INFOCUS_VCM)GetProcAddress(hDll, "cal_otp_pdaf_dcc_get_infocus_vcm");
    if (cal_otp_pdaf_dcc_get_infocus_vcm == NULL){
        printf("Failed to GetProcAddress cal_otp_pdaf_dcc_get_infocus_vcm\n");
        goto EXIT;
    }

	cal_otp_pdaf_dcc_releaseraw = (FNUC_CAL_OTP_PDAF_DCC_RELEASERAW)GetProcAddress(hDll, "cal_otp_pdaf_dcc_releaseraw");
    if (cal_otp_pdaf_dcc_releaseraw == NULL){
        printf("Failed to GetProcAddress cal_otp_pdaf_dcc_releaseraw\n");
        goto EXIT;
    }

	cal_otp_pdaf_dcc_releaseraw_v = (FNUC_CAL_OTP_PDAF_DCC_RELEASERAW_V)GetProcAddress(hDll, "cal_otp_pdaf_dcc_releaseraw_v");
    if (cal_otp_pdaf_dcc_releaseraw_v == NULL){
        printf("Failed to GetProcAddress cal_otp_pdaf_dcc_releaseraw_v\n");
        goto EXIT;
    }
    cal_otp_pdaf_dcc_deinit = (FNUC_CAL_OTP_PDAF_DCC_DEINIT)GetProcAddress(hDll, "cal_otp_pdaf_dcc_deinit");
	if (cal_otp_pdaf_dcc_deinit == NULL){
        printf("Failed to GetProcAddress cal_otp_pdaf_dcc_deinit\n");
        goto EXIT;
	}

// 1. spc calibration 
	// 1.1 spc initialization
	if (SPC_DCC_SWITCH < 2){
		rtn = cal_otp_pdaf_spc_init(spc_parameter.c_str());
		if (rtn != ERR_CODE_PASS){
			return rtn;
		}
		// 1.2 get raw to image buffer
		int **raw_image_spc_calc = NULL;
		const char *spc_calc_raw_path[SPC_RAW_SEQUENCE_NUMBER] = {
			spc_raw_path[0].c_str(),
			spc_raw_path[1].c_str()
		};
		rtn = cal_otp_pdaf_spc_getraw(spc_calc_raw_path, &raw_image_spc_calc);
		if (rtn != ERR_CODE_PASS){
			goto RELEASE_SPC;
		}

	// 1.3 spc calculation
	rtn = cal_otp_pdaf_spc(raw_image_spc_calc, spc_gain_map, otp_ppp_out);

RELEASE_SPC:
	// 1.4 release image buffer
	cal_otp_pdaf_spc_releaseraw (raw_image_spc_calc);
	// 1.5 spc deinitialization
	cal_otp_pdaf_spc_deinit ();

	if(rtn!=ERR_CODE_PASS){
		return rtn;
	}

	// output SPC calibration .bin data (i.e., write spc data to OTP)
	FILE *fp_otp_spc = fopen ("otp_spc.bin","wb");
	unsigned char spc_w = SPC_MAP_W;
	unsigned char spc_h = SPC_MAP_H;
	fwrite (&spc_w, 1, 1, fp_otp_spc);
	fwrite (&spc_h, 1, 1, fp_otp_spc);
	fwrite (spc_gain_map, 1, spc_w*spc_h*2*2, fp_otp_spc);
	fclose (fp_otp_spc);
	
// 2. spc verification
	// 2.1 spc initialization
	rtn = cal_otp_pdaf_spc_init(spc_verify_parameter.c_str());
	if(rtn!=ERR_CODE_PASS){
		return rtn;
	}
	// 2.2 get raw to image buffer
	int **raw_image_spc_varify = NULL;
	const char *spc_veri_raw_path[SPC_RAW_SEQUENCE_NUMBER_V] = {spc_verify_raw_path[0].c_str()};
	rtn = cal_otp_pdaf_spc_getraw_v(spc_veri_raw_path, &raw_image_spc_varify);
	if(rtn!=ERR_CODE_PASS){
		goto RELEASE_SPC_VERIFY;
	}
	// 2.3 copy spc data from the OTP to a buffer
	for (int i = 0; i < SPC_MAP_W*SPC_MAP_H*2*2; i ++)
		otp_spc_in[i] = spc_gain_map[i];
	// 2.4 verification 
	rtn = cal_otp_pdaf_spc_verify(raw_image_spc_varify, otp_spc_in, otp_ppp_out); // CY: spc_gain_map need modify to 9x7x2 bytes

RELEASE_SPC_VERIFY:
	// 2.5 release image buffer
	cal_otp_pdaf_spc_releaseraw_v (raw_image_spc_varify);
	// 2.6 spc deinitialization
	cal_otp_pdaf_spc_deinit ();

		if (rtn != ERR_CODE_PASS){
			return rtn;
		}
	}
// 4. dcc calibration 
	// 4.1 dcc initialization
	if (SPC_DCC_SWITCH == 0 || SPC_DCC_SWITCH == 2){
		rtn = cal_otp_pdaf_dcc_init(dcc_parameter.c_str());
		if (rtn != ERR_CODE_PASS){
			return rtn;
		}
		// 4.2 get raw to image buffer
		int **raw_image_dcc_calc = NULL;
		const char *dcc_calc_raw_path[DCC_RAW_SEQUENCE_NUMBER] = {
			dcc_raw_path[0].c_str(),
			dcc_raw_path[1].c_str(),
			dcc_raw_path[2].c_str(),
			dcc_raw_path[3].c_str(),
			dcc_raw_path[4].c_str(),
			dcc_raw_path[5].c_str(),
		};
		rtn = cal_otp_pdaf_dcc_getraw(dcc_calc_raw_path, &raw_image_dcc_calc, DCC_RAW_SEQUENCE_NUMBER);
		if (rtn != ERR_CODE_PASS){
			goto RELEASE_DCC;
		}
		// 4.3 copy spc data from the OTP to a buffer
		if (SPC_DCC_SWITCH == 2){
			FILE *fp_open_spc_forDCC = fopen("otp_spc.bin", "rb");
			fseek(fp_open_spc_forDCC, 2L, 0);
			fread(otp_spc_in, 1, (SPC_MAP_W*SPC_MAP_H * 2 * 2), fp_open_spc_forDCC);
			fclose(fp_open_spc_forDCC);
		}
		else
		{
			for (int i = 0; i < SPC_MAP_W*SPC_MAP_H * 2 * 2; i++)
				otp_spc_in[i] = spc_gain_map[i];
		}
		// 4.4 dcc calculation 
		if (SPC_DCC_SWITCH == 2){
			FILE *fp_ppp_copy = fopen("otp_ppp.bin", "rb");
			fread(otp_ppp_out, 1, (PD_PROFILE_TABLE_NUM - 4), fp_ppp_copy);
			fclose(fp_ppp_copy);
		}
		rtn = cal_otp_pdaf_dcc(raw_image_dcc_calc, otp_spc_in, VCM_LOW_BND, VCM_UPP_BND, dcc_coef_map, otp_ppp_out);

RELEASE_DCC:
	// 4.5 release image buffer
	cal_otp_pdaf_dcc_releaseraw (raw_image_dcc_calc);
	// 4.6 dcc deinitialization
	cal_otp_pdaf_dcc_deinit ();

	if(rtn!=ERR_CODE_PASS){
		return rtn;
	}

	// output DCC calibration .bin data (i.e., write dcc data to OTP)
	FILE *fp_otp_dcc = fopen ("otp_dcc.bin","wb");
	unsigned char dcc_w = DCC_XKNOT_NUM;
	unsigned char dcc_h = DCC_YKNOT_NUM;
	fwrite (&dcc_w, 1, 1, fp_otp_dcc);
	fwrite (&dcc_h, 1, 1, fp_otp_dcc);
	fwrite (dcc_coef_map, 1, dcc_w*dcc_h*2, fp_otp_dcc);
	fclose (fp_otp_dcc);

// 5. dcc calibration verify
	// 5.1 dcc initialization
	rtn = cal_otp_pdaf_dcc_init (dcc_verify_parameter.c_str());
	if(rtn!=ERR_CODE_PASS){
		return rtn;
	}
	// 5.2 get raw to image buffer
	int **raw_image_dcc_verify = NULL;
	const char *dcc_veri_raw_path[DCC_RAW_SEQUENCE_NUMBER_V] = {dcc_verify_raw_path[0].c_str()};
	rtn = cal_otp_pdaf_dcc_getraw_v(dcc_veri_raw_path, &raw_image_dcc_verify);
	if(rtn!=ERR_CODE_PASS){
		goto RELEASE_DCC_VERIFY;
	}
	// 5.3 Copy dcc data from the OTP to a buffer
	for (int i = 0; i < DCC_XKNOT_NUM*DCC_YKNOT_NUM*2; i ++)
		otp_dcc_in[i] = dcc_coef_map[i];
	// 5.4 Copy spc data from the OTP to a buffer  
	if (SPC_DCC_SWITCH == 0){
		for (int i = 0; i < SPC_MAP_W*SPC_MAP_H*2*2; i ++)
			otp_spc_in[i] = spc_gain_map[i];
	}
	// 5.5 dcc verification 
	int vcm_offset;
	rtn = cal_otp_pdaf_dcc_get_infocus_vcm (raw_image_dcc_verify, otp_spc_in, otp_dcc_in, vcm_offset);
	int pdaf_infocus_pos = current_vcm_pos + vcm_offset;

	RELEASE_DCC_VERIFY:
		// 5.6 release image buffer
		cal_otp_pdaf_dcc_releaseraw_v(raw_image_dcc_verify);
		// 5.7 dcc deinitialization
		cal_otp_pdaf_dcc_deinit();
		// 5.8 do CDAF, get the vcm position with the peakest contrast value to "cdaf_infocus_pos"
		int cdaf_infocus_pos = 366;
		// 5.9 joint PDAF and CDAF infocus verification, 
		infocus_pos_error = (abs(pdaf_infocus_pos - cdaf_infocus_pos) > 0xff) ? 0xff : abs(pdaf_infocus_pos - cdaf_infocus_pos);
		printf("the diff between pdaf and cdaf is [%d]\n",infocus_pos_error);
		if (infocus_pos_error >= error_scope){
			rtn = ERR_CODE_OUT_ERROR_SCOPE;
			return rtn;
		}
	}

	// output Pd Pixel Profile calibration .bin data (i.e., write ppp data to OTP)
	if (SPC_DCC_SWITCH  == 1)
	{
		FILE *fp_otp_ppp = fopen("otp_ppp.bin", "wb");
		fwrite(otp_ppp_out, 1, PD_PROFILE_TABLE_NUM - 4, fp_otp_ppp);
		fclose(fp_otp_ppp);
	}
	else
	{
		FILE *fp_otp_ppp = fopen("otp_ppp.bin", "wb");
		fwrite(otp_ppp_out, 1, PD_PROFILE_TABLE_NUM, fp_otp_ppp);
		fwrite(&infocus_pos_error, 1, 1, fp_otp_ppp);
		fclose(fp_otp_ppp);
	}
	printf("===========================================\n");
	printf("=============calibration done!!!===========\n");
	printf("===========================================\n");
EXIT:
    if (hDll != NULL)
    {
        FreeLibrary(hDll);
    }

	return rtn;
}