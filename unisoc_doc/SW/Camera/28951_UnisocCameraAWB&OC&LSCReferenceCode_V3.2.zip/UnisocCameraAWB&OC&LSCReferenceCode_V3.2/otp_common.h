#ifndef OTP_COMMON_H_
#define OTP_COMMON_H_


#include "sci_types.h"


uint8_t otp_checksum(uint8_t* data, uint32_t sz);


#endif // OTP_COMMON_H_