#ifndef _OTP_CALI_H_
#define _OTP_CALI_H_

#include "sci_types.h"


#ifdef __cplusplus
extern "C"
{
#endif


#ifdef OTPSHTOOL_EXPORTS
#define OTPSHTOOL_API __declspec(dllexport)
#else
#define OTPSHTOOL_API __declspec(dllimport)
#endif


// calibrate white balance
// input arguments:
// * raw setting *
//uint16_t* raw_image_random_factory: raw data of random module in factory
//uint32_t raw_width: raw image width in pixel
//uint32_t raw_height: raw image height in pixel 
//uint32_t bayer_pattern: raw image bayer pattern, 0 - Gr first, 1 - R first, 2 - B first, 3 - Gb first
// * BLC setting *
//uint16_t blc_r: blc value for r channel
//uint16_t blc_gr: blc value for gr channel
//uint16_t blc_gb: blc value for gb channel
//uint16_t blc_b: blc value for b channel
// * AWB ROI setting *
//uint32_t awb_roi_x, uint32_t awb_roi_y, uint32_t awb_roi_w, uint32_t awb_roi_h, 
// output arguments:
//uint16_t* awb_r: r mean in ROI 
//uint16_t* awb_g: g mean in ROI
//uint16_t* awb_b: b mean in ROI
// return information: if < 0, it is error parameter; if 0, it is ok
typedef int32_t (*FUNC_CAL_OTP_AWB)(uint16_t* raw_image_random_factory, uint32_t raw_width, uint32_t raw_height, uint32_t bayer_pattern, 
                                    uint16_t blc_r, uint16_t blc_gr, uint16_t blc_gb, uint16_t blc_b,
                                    uint32_t awb_roi_x, uint32_t awb_roi_y, uint32_t awb_roi_w, uint32_t awb_roi_h, 
                                    uint16_t* awb_r, uint16_t* awb_g, uint16_t* awb_b);
OTPSHTOOL_API int32_t cal_otp_awb(uint16_t* raw_image_random_factory, uint32_t raw_width, uint32_t raw_height, uint32_t bayer_pattern, 
                                  uint16_t blc_r, uint16_t blc_gr, uint16_t blc_gb, uint16_t blc_b, 
                                  uint32_t awb_roi_x, uint32_t awb_roi_y, uint32_t awb_roi_w, uint32_t awb_roi_h, 
                                  uint16_t* awb_r, uint16_t* awb_g, uint16_t* awb_b);





// calibrate optical center
// input arguments:
// * raw setting *
//uint16_t* raw_image_random_factory: raw data of random module in factory
//uint32_t raw_width: raw image width in pixel
//uint32_t raw_height: raw image height in pixel 
//uint32_t bayer_pattern: raw image bayer pattern, 0 - Gr first, 1 - R first, 2 - B first, 3 - Gb first
// * BLC setting *
//uint16_t blc_r: blc value for r channel
//uint16_t blc_gr: blc value for gr channel
//uint16_t blc_gb: blc value for gb channel
//uint16_t blc_b: blc value for b channel
// output arguments:
//uint16_t* oc_x_r: optical center x value of r channel
//uint16_t* oc_y_r: optical center y value of r channel
//uint16_t* oc_x_gr: optical center x value of gr channel
//uint16_t* oc_y_gr: optical center y value of gr channel
//uint16_t* oc_x_gb: optical center x value of gb channel
//uint16_t* oc_y_gb: optical center y value of gb channel
//uint16_t* oc_x_b: optical center x value of b channel
//uint16_t* oc_y_b: optical center y value of b channel
// return information: if < 0, it is error parameter; if 0, it is ok
typedef int32_t (*FUNC_CAL_OTP_OC)(uint16_t* raw_image_random_factory, uint32_t raw_width, uint32_t raw_height, uint32_t bayer_pattern, 
                                   uint16_t blc_r, uint16_t blc_gr, uint16_t blc_gb, uint16_t blc_b, 
                                   uint16_t* oc_x_r, uint16_t* oc_y_r, uint16_t* oc_x_gr, uint16_t* oc_y_gr, uint16_t* oc_x_gb, uint16_t* oc_y_gb, uint16_t* oc_x_b, uint16_t* oc_y_b);
OTPSHTOOL_API int32_t cal_otp_oc(uint16_t* raw_image_random_factory, uint32_t raw_width, uint32_t raw_height, uint32_t bayer_pattern, 
                                 uint16_t blc_r, uint16_t blc_gr, uint16_t blc_gb, uint16_t blc_b, 
                                 uint16_t* oc_x_r, uint16_t* oc_y_r, uint16_t* oc_x_gr, uint16_t* oc_y_gr, uint16_t* oc_x_gb, uint16_t* oc_y_gb, uint16_t* oc_x_b, uint16_t* oc_y_b);





// calibrate lens shading correction
// input arguments:
// * raw setting *
//uint16_t* raw_image_random_factory: raw data of random module in factory
//uint32_t raw_width: raw image width in pixel
//uint32_t raw_height: raw image height in pixel 
//uint32_t bayer_pattern: raw image bayer pattern, 0 - Gr first, 1 - R first, 2 - B first, 3 - Gb first
// * BLC setting *
//uint16_t blc_r: blc value for r channel
//uint16_t blc_gr: blc value for gr channel
//uint16_t blc_gb: blc value for gb channel
//uint16_t blc_b: blc value for b channel
// * LSC setting *
// uint32_t lsc_grid: lsc grid, such as 32, 64, 96 or 128
// * other setting *
// is_lsc_compression: lsc table compression or not
// output arguments:
//uint16_t* lsc_otp: lsc table buffer, if lsc is not compressed, then it is r/gr/gb/b table in order
//uint32_t* lsc_size: lsc table buffer size in byte
// return information: if < 0, it is error parameter; if 0, it is ok
typedef int32_t (*FUNC_CAL_OTP_LSC)(uint16_t* raw_image_random_factory, uint32_t raw_width, uint32_t raw_height, uint32_t bayer_pattern, 
                                    uint16_t blc_r, uint16_t blc_gr, uint16_t blc_gb, uint16_t blc_b,
                                    uint32_t lsc_grid, uint16_t* lsc_otp, uint32_t* lsc_size, uint32_t is_lsc_compression);
OTPSHTOOL_API int32_t cal_otp_lsc(uint16_t* raw_image_random_factory, uint32_t raw_width, uint32_t raw_height, uint32_t bayer_pattern, 
                                  uint16_t blc_r, uint16_t blc_gr, uint16_t blc_gb, uint16_t blc_b, 
                                  uint32_t lsc_grid, uint16_t* lsc_otp, uint32_t* lsc_size, uint32_t is_lsc_compression);








// verify otp
// input arguments:
//uint16_t* raw_image: raw data
//uint32_t raw_width: raw image width in pixel
//uint32_t raw_height: raw image height in pixel 
//uint32_t bayer_pattern: raw image bayer pattern, 0 - Gr first, 1 - R first, 2 - B first, 3 - Gb first
// * BLC setting *
//uint16_t blc_r: blc value for r channel
//uint16_t blc_gr: blc value for gr channel
//uint16_t blc_gb: blc value for gb channel
//uint16_t blc_b: blc value for b channel
// * LSC setting *
// uint32_t lsc_grid: lsc grid, such as 32, 64, 96 or 128
// uint16_t* lsc_otp: otp lsc table
// uint32_t lsc_size: otp lsc size
// is_lsc_compression: lsc table compression or not
// uint16_t awb_r: otp r value
// uint16_t awb_g: otp g value
// uint16_t awb_b: otp b value
// output arguments:
//uint8_t* raw_image_output: output raw data
// return information: if 0, it is ok; else failed
typedef int32_t (*FUNC_VERIFY_OTP_LSC_AWB)(uint16_t* raw_image, uint32_t raw_width, uint32_t raw_height, uint32_t bayer_pattern, uint16_t* raw_image_output, 
                                           uint16_t blc_r, uint16_t blc_gr, uint16_t blc_gb, uint16_t blc_b, 
                                           uint32_t lsc_grid, uint16_t* lsc_otp, uint32_t lsc_size, uint32_t is_lsc_compression, 
                                           uint16_t awb_r, uint16_t awb_g, uint16_t awb_b);
OTPSHTOOL_API int32_t verify_otp_lsc_awb(uint16_t* raw_image, uint32_t raw_width, uint32_t raw_height, uint32_t bayer_pattern, uint16_t* raw_image_output, 
                                         uint16_t blc_r, uint16_t blc_gr, uint16_t blc_gb, uint16_t blc_b, 
                                         uint32_t lsc_grid, uint16_t* lsc_otp, uint32_t lsc_size, uint32_t is_lsc_compression, 
                                         uint16_t awb_r, uint16_t awb_g, uint16_t awb_b);



#ifdef __cplusplus
}
#endif

#endif
