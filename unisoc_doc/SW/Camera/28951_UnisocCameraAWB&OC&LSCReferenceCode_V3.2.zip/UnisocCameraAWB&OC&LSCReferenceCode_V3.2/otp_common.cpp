#include "otp_common.h"




uint8_t otp_checksum(uint8_t* data, uint32_t sz)
{
    int sum = 0;
    
    for (uint32_t i=0; i<sz; i++)
    {
        sum += data[i];
    }
    
    uint8_t checksum = sum % 256;
    
    return checksum;
}
