#include <stdio.h>
#include <time.h>
#include <windows.h>

#include "otp_cali.h"
#include "otp_map.h"







static int lsc_gain_14bits_to_16bits(unsigned short *src_14bits, unsigned short *dst_16bits, unsigned int width, unsigned int height)
{
    unsigned int gain_compressed_bits = 14;
    unsigned int gain_origin_bits = 16;
    
    unsigned int i = 0;
    unsigned int j = 0;
    unsigned int bit_left = 0;
    unsigned int bit_buf = 0;
    unsigned int offset = 0;
    unsigned int dst_gain_num = 0;
    
    unsigned int src_uncompensate_bytes = width*height*gain_compressed_bits%gain_origin_bits;
    unsigned int cmp_bits = width * height* gain_compressed_bits;
    unsigned int src_bytes = (cmp_bits + gain_origin_bits - 1) / gain_origin_bits * (gain_origin_bits / 8);
    
    
    if (0 == src_bytes || 0 != (src_bytes & 1))
    {
        return 0;
    }
    
    for (i=0; i<src_bytes/2; i++)
    {
        bit_buf |= src_14bits[i] << bit_left;
        bit_left += 16;
        
        if (bit_left > gain_compressed_bits)
        {
            offset = 0;
            while (bit_left >= gain_compressed_bits)
            {
                dst_16bits[j] = (unsigned short)(bit_buf & 0x3fff);
                j++;
                bit_left -= gain_compressed_bits;
                bit_buf = (bit_buf >> gain_compressed_bits);
            }
        }
    }
    
    if (gain_compressed_bits == src_uncompensate_bytes)
    {
        dst_gain_num = j-1;
    }
    else
    {
        dst_gain_num = j;
    }
    
    return dst_gain_num;
}


static int dump_lsc_gain_binary(unsigned short* gain, unsigned int size, const char* filename)
{
    FILE* fp = fopen(filename, "wb");
    if (fp == NULL)
    {
        return -1;
    }
    
    if (fwrite(gain, 1, size, fp) != size)
    {
        fclose(fp);
        return -1;
    }
    
    fclose(fp);
    
    return 0;
}

static int dump_lsc_gain_table(unsigned short* gain, int width, int height, const char* filename)
{
    FILE* fp = fopen(filename, "w");
    if (fp == NULL)
    {
        return -1;
    }
    
    for (int j=0; j<height; j++)
    {
        for (int i=0; i<width; i++)
        {
            fprintf(fp, " %4d,", gain[j*width+i]);
        }
        fprintf(fp, "\r\n");
    }
    fclose(fp);
    
    return 0;
}



static int read_unpacked_raw(unsigned short* praw, unsigned int width, unsigned int height, const char* filename)
{
    FILE* fp_raw = fopen(filename, "rb");
    if (fp_raw == NULL)
    {
        return -1;
    }
    
    if (fread(praw, 1, width*height*16/8, fp_raw) != (width*height * 16/8))
    {
        fclose(fp_raw);
        return -1;
    }
    
    fclose(fp_raw);
    
    return 0;
}

static int write_unpacked_raw(unsigned short* praw, unsigned int width, unsigned int height, const char* filename)
{
    FILE* fp_raw = fopen(filename, "wb");
    if (fp_raw == NULL)
    {
        return -1;
    }
    
    if (fwrite(praw, 1, width*height*16/8, fp_raw) != (width*height * 16/8))
    {
        fclose(fp_raw);
        return -1;
    }
    
    fclose(fp_raw);
    
    return 0;
}



int main(int argc, char* argv[])
{
    // input: raw, now only support 16bits raw
    const char* raw_filename = "input.raw";
    
    /******************** please check below parameters *********************/
#if 1
    uint32_t raw_width = 3264;
    uint32_t raw_height = 2448;
    uint32_t bayer_pattern = 2;  /* 0 - Gr, 1 - R, 2 - B, 3 - Gb */
    
    uint16_t blc_r = 64; /* OB value */
    uint16_t blc_gr = 64; /* OB value */
    uint16_t blc_gb = 64; /* OB value */
    uint16_t blc_b = 64; /* OB value */
    
    // input: ROI of AWB
    uint32_t awb_roi_w = raw_width/8 / 2 * 2; // raw_width/8, center 1/8 is recommended, must be even number
    uint32_t awb_roi_h = raw_height/8 / 2 * 2; // raw_height/8, center 1/8 is recommended, must be even number
    uint32 awb_roi_x = (raw_width-awb_roi_w)/2 / 2 * 2; // must be even number
    uint32 awb_roi_y = (raw_height-awb_roi_h)/2 / 2 * 2; // must be even number
    
    // input: LSC grid
    uint32_t lsc_grid = 96;
    
    // input: otp
    
#endif
    /****************** please check above parameters *******************************/
    
    
    
#if 0
    uint32_t raw_width = 4208;
    uint32_t raw_height = 3120;
    uint32_t bayer_pattern = 1;  /* 0 - Gr, 1 - R, 2 - B, 3 - Gb */
    
    uint16_t blc_r = 64; /* OB value */
    uint16_t blc_gr = 64; /* OB value */
    uint16_t blc_gb = 64; /* OB value */
    uint16_t blc_b = 64; /* OB value */
    
    // input: ROI of AWB
    uint32_t awb_roi_w = raw_width/8 / 2 * 2; // raw_width/8, center 1/8 is recommended, must be even number
    uint32_t awb_roi_h = raw_height/8 / 2 * 2; // raw_height/8, center 1/8 is recommended, must be even number
    uint32 awb_roi_x = (raw_width-awb_roi_w)/2 / 2 * 2; // must be even number
    uint32 awb_roi_y = (raw_height-awb_roi_h)/2 / 2 * 2; // must be even number
    
    // input: LSC grid
    uint32_t lsc_grid = 96;
#endif
    
    
    PTR_FUNC_SAVE_OTP_BIN save_otp_bin = save_otp_8KB_sample;	// please refer your project otp map
    char* filename_otp = "otp_8KB.bin";
    
    
    const char* raw_filename_output = "output.raw";
    
    
    
    
    // output
    // awb output, AWB@OTP
    uint16_t awb_r = 0;
    uint16_t awb_g = 0;
    uint16_t awb_b = 0;
    
    // optical center output, OC@OTP
    uint16_t oc_x_r = (uint16_t)raw_width/2;
    uint16_t oc_y_r = (uint16_t)raw_height/2;
    uint16_t oc_x_gr = (uint16_t)raw_width/2;
    uint16_t oc_y_gr = (uint16_t)raw_height/2;
    uint16_t oc_x_gb = (uint16_t)raw_width/2;
    uint16_t oc_y_gb = (uint16_t)raw_height/2;
    uint16_t oc_x_b = (uint16_t)raw_width/2;
    uint16_t oc_y_b = (uint16_t)raw_height/2;
    
    // lsc shading table, lsc@OTP
    uint16_t lsc_gain[4096] = {0};
    uint32_t lsc_size = 0;
    uint32_t is_lsc_compression = 0; /* please keep it as 0, it doesn't support lsc table compression yet */
    uint16_t lsc_table[4096] = {0};
    uint32_t lsc_width = 0;
    uint32_t lsc_height = 0;
    
    
    
    
    HINSTANCE hDll = NULL;
    FUNC_CAL_OTP_AWB cal_otp_awb = NULL;
    FUNC_CAL_OTP_OC cal_otp_oc = NULL;
    FUNC_CAL_OTP_LSC cal_otp_lsc = NULL;
    FUNC_VERIFY_OTP_LSC_AWB verify_otp_lsc_awb = NULL;
    unsigned short* raw_image_input = NULL;
    unsigned short* raw_image_output = NULL;
    int ret = 0;
    
    
    
    /*get dll handle*/
#ifdef _WIN64
    hDll = LoadLibrary("OTPshTool_x64.dll");
	printf("LoadLibrary name: OTPshTool_x64.dll\n");
#else
	hDll = LoadLibrary("OTPshTool_win32.dll");
	printf("LoadLibrary name: OTPshTool_win32.dll\n");
#endif
	
    if (hDll == NULL)
    {
        printf("Failed to load OTPshTool.dll\n");
        goto EXIT;
    }
    
    /*get function pointer*/
    cal_otp_awb = (FUNC_CAL_OTP_AWB)GetProcAddress(hDll, "cal_otp_awb");
    if (cal_otp_awb == NULL)
    {
        printf("Failed to GetProcAddress cal_otp_awb\n");
        goto EXIT;
    }
    
    cal_otp_oc = (FUNC_CAL_OTP_OC)GetProcAddress(hDll, "cal_otp_oc");
    if (cal_otp_oc == NULL)
    {
        printf("Failed to GetProcAddress cal_otp_oc\n");
        goto EXIT;
    }
    
    cal_otp_lsc = (FUNC_CAL_OTP_LSC)GetProcAddress(hDll, "cal_otp_lsc");
    if (cal_otp_lsc == NULL)
    {
        printf("Failed to GetProcAddress cal_otp_lsc\n");
        goto EXIT;
    }
    
    verify_otp_lsc_awb = (FUNC_VERIFY_OTP_LSC_AWB)GetProcAddress(hDll, "verify_otp_lsc_awb");
    
    
    
    // read raw image
    raw_image_input = (unsigned short*)malloc(raw_width * raw_height * sizeof(uint16_t));
    if (raw_image_input == NULL)
    {
        printf("Failed to malloc memory\n");
        goto EXIT;
    }
    if (read_unpacked_raw(raw_image_input, raw_width, raw_height, raw_filename) != 0)
    {
        printf("Failed to read file %s\n", raw_filename);
        goto EXIT;
    }
    
    raw_image_output = (unsigned short*)malloc(raw_width * raw_height * sizeof(uint16_t));
    
    
    
    
    
    ret = cal_otp_awb(raw_image_input, raw_width, raw_height, bayer_pattern, blc_r, blc_gr, blc_gb, blc_b, awb_roi_x, awb_roi_y, awb_roi_w, awb_roi_h, &awb_r, &awb_g, &awb_b);
    if (ret < 0)
    {
        printf("error parameter\n");
        goto EXIT;
    }
    printf("AWB@OTP: (%d, %d, %d) or (0x%x, 0x%x, 0x%x)\n", awb_r, awb_g, awb_b, awb_r, awb_g, awb_b);
    
    
    
    ret = cal_otp_oc(raw_image_input, raw_width, raw_height, bayer_pattern, blc_r, blc_gr, blc_gb, blc_b, &oc_x_r, &oc_y_r, &oc_x_gr, &oc_y_gr, &oc_x_gb, &oc_y_gb, &oc_x_b, &oc_y_b);
    if (ret < 0)
    {
        printf("error parameter\n");
        goto EXIT;
    }
    printf("OC@OTP: r(%d,%d) gr(%d,%d) gb(%d,%d) b(%d,%d) or r(0x%x,0x%x) gr(0x%x,0x%x) gb(0x%x,0x%x) b(0x%x,0x%x)\n", oc_x_r, oc_y_r, oc_x_gr, oc_y_gr, oc_x_gb, oc_y_gb, oc_x_b, oc_y_b, oc_x_r, oc_y_r, oc_x_gr, oc_y_gr, oc_x_gb, oc_y_gb, oc_x_b, oc_y_b);
    
    
    
    ret = cal_otp_lsc(raw_image_input, raw_width, raw_height, bayer_pattern, blc_r, blc_gr, blc_gb, blc_b, lsc_grid, lsc_gain, &lsc_size, is_lsc_compression);
    if (ret < 0)
    {
        printf("error parameter\n");
        goto EXIT;
    }
    printf("LSC@OTP size = %d Bytes\n", lsc_size);
    
    
    
    
    
    // verify
    if ((verify_otp_lsc_awb != NULL) && (raw_image_output != NULL))
    {
        verify_otp_lsc_awb(raw_image_input, raw_width, raw_height, bayer_pattern, raw_image_output, blc_r, blc_gr, blc_gb, blc_b, lsc_grid, lsc_gain, lsc_size, is_lsc_compression, awb_r, awb_g, awb_b);
        
        write_unpacked_raw(raw_image_output, raw_width, raw_height, raw_filename_output);
    }
    
    
    
    
    // save awb/oc/lsc@OTP to otp.bin
    save_otp_bin(awb_r, awb_g, awb_b, oc_x_r, oc_y_r, oc_x_gr, oc_y_gr, oc_x_gb, oc_y_gb, oc_x_b, oc_y_b, (uint16_t)raw_width, (uint16_t)raw_height, (uint8_t)lsc_grid, lsc_gain, lsc_size, filename_otp);
    
    
    
    // dump lsc table
#if 1
    lsc_width = (((raw_width / 2) % lsc_grid) > 0) ? ((raw_width / 2) / lsc_grid + 2) : ((raw_width / 2) / lsc_grid + 1);
    lsc_height = (((raw_height / 2) % lsc_grid) > 0) ? ((raw_height / 2) / lsc_grid + 2) : ((raw_height / 2) / lsc_grid + 1);
    lsc_gain_14bits_to_16bits(lsc_gain + lsc_size/4 / 2 * 0, lsc_table + lsc_width * lsc_height * 0, lsc_width, lsc_height);
    lsc_gain_14bits_to_16bits(lsc_gain + lsc_size/4 / 2 * 1, lsc_table + lsc_width * lsc_height * 1, lsc_width, lsc_height);
    lsc_gain_14bits_to_16bits(lsc_gain + lsc_size/4 / 2 * 2, lsc_table + lsc_width * lsc_height * 2, lsc_width, lsc_height);
    lsc_gain_14bits_to_16bits(lsc_gain + lsc_size/4 / 2 * 3, lsc_table + lsc_width * lsc_height * 3, lsc_width, lsc_height);
    dump_lsc_gain_table(lsc_table + lsc_width * lsc_height * 0, lsc_width, lsc_height, "lsc_r.txt");
    dump_lsc_gain_table(lsc_table + lsc_width * lsc_height * 1, lsc_width, lsc_height, "lsc_gr.txt");
    dump_lsc_gain_table(lsc_table + lsc_width * lsc_height * 2, lsc_width, lsc_height, "lsc_gb.txt");
    dump_lsc_gain_table(lsc_table + lsc_width * lsc_height * 3, lsc_width, lsc_height, "lsc_b.txt");
#endif
    
    
    
    
EXIT:
    if (raw_image_output != NULL)
    {
        free(raw_image_output);
    }
    
    if (raw_image_input != NULL)
    {
        free(raw_image_input);
    }
    
    if (hDll != NULL)
    {
        FreeLibrary(hDll);
    }
    
    
    return 0;
}
