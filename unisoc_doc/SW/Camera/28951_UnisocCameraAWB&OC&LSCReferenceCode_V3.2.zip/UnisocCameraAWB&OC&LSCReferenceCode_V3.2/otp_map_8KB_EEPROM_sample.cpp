#include <stdio.h>
#include <memory.h>
#include <time.h>
#include "otp_map.h"
#include "otp_common.h"



void save_otp_8KB_sample(uint16_t awb_r, uint16_t awb_g, uint16_t awb_b, 
                     uint16_t oc_x_r, uint16_t oc_y_r, uint16_t oc_x_gr, uint16_t oc_y_gr, uint16_t oc_x_gb, uint16_t oc_y_gb, uint16_t oc_x_b, uint16_t oc_y_b,
                     uint16_t raw_width, uint16_t raw_height, uint8_t lsc_grid, uint16_t* lsc_gain, uint32_t lsc_size,
                     const char* filename_otp)
{
    uint32_t channel_size = lsc_size / 4;
    uint16_t* lsc_r_gain = lsc_gain + channel_size/2 * 0;
    uint16_t* lsc_gr_gain = lsc_gain + channel_size/2 * 1;
    uint16_t* lsc_gb_gain = lsc_gain + channel_size/2 * 2;
    uint16_t* lsc_b_gain = lsc_gain + channel_size/2 * 3;
    
    
    unsigned char otp[8192] = {0};
    
    
    // header section, please fill all header data according to otp map
    otp[0x00] = 'S';
    otp[0x01] = 'P';
    otp[0x02] = 'R';
    otp[0x03] = 'D';
    otp[0x04] = 1;
    otp[0x05] = 0;
    
    
    time_t long_time;
    time(&long_time);
    struct tm* ptime = localtime(&long_time);
    otp[0x10] = ptime->tm_year - 100;
    otp[0x11] = ptime->tm_mon + 1;
    otp[0x12] = ptime->tm_mday;
    
    
    
    // AWB section
    otp[0x5D] = awb_r & 0xFF;
    otp[0x5E] = awb_r >> 8;
    otp[0x5F] = awb_g & 0xFF;
    otp[0x60] = awb_g >> 8;
    otp[0x61] = awb_b & 0xFF;
    otp[0x62] = awb_b >> 8;
    
    
    
    // Shading section
    otp[0x6A] = 0;
    
    otp[0x6B] = oc_x_r & 0xFF;
    otp[0x6C] = oc_x_r >> 8;
    otp[0x6D] = oc_y_r & 0xFF;
    otp[0x6E] = oc_y_r >> 8;
    otp[0x6F] = oc_x_gr & 0xFF;
    otp[0x70] = oc_x_gr >> 8;
    otp[0x71] = oc_y_gr & 0xFF;
    otp[0x72] = oc_y_gr >> 8;
    otp[0x73] = oc_x_gb & 0xFF;
    otp[0x74] = oc_x_gb >> 8;
    otp[0x75] = oc_y_gb & 0xFF;
    otp[0x76] = oc_y_gb >> 8;
    otp[0x77] = oc_x_b & 0xFF;
    otp[0x78] = oc_x_b >> 8;
    otp[0x79] = oc_y_b & 0xFF;
    otp[0x7A] = oc_y_b >> 8;
    
    otp[0x7B] = raw_width & 0xFF;
    otp[0x7C] = raw_width >> 8;
    otp[0x7D] = raw_height & 0xFF;
    otp[0x7E] = raw_height >> 8;
    otp[0x7F] = lsc_grid;
    
    memcpy(otp+0x0080, lsc_r_gain, channel_size);
    memcpy(otp+0x023A, lsc_gr_gain, channel_size);
    memcpy(otp+0x03F4, lsc_gb_gain, channel_size);
    memcpy(otp+0x05AE, lsc_b_gain, channel_size);
    otp[0x0768] = otp_checksum(&otp[0x6A], 0x768-0x6A);
    
    
    
    FILE* fp = fopen(filename_otp, "wb");
    if (fp != NULL)
    {
        fwrite(otp, 1, 8192, fp);
        
        fclose(fp);
    }
}
