#ifndef OTP_MAP_H_
#define OTP_MAP_H_


#include "sci_types.h"


typedef void (FUNC_SAVE_OTP_BIN)(uint16_t awb_r, uint16_t awb_g, uint16_t awb_b, 
                               uint16_t oc_x_r, uint16_t oc_y_r, uint16_t oc_x_gr, uint16_t oc_y_gr, uint16_t oc_x_gb, uint16_t oc_y_gb, uint16_t oc_x_b, uint16_t oc_y_b,
                               uint16_t raw_width, uint16_t raw_height, uint8_t lsc_grid, uint16_t* lsc_gain, uint32_t lsc_size,
                               const char* filename_otp);

typedef FUNC_SAVE_OTP_BIN * PTR_FUNC_SAVE_OTP_BIN;


FUNC_SAVE_OTP_BIN save_otp_8KB_sample;

#endif // OTP_MAP_H_